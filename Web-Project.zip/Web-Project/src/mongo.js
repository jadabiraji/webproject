const mongoose=require("mongoose")

mongoose.connect("mongodb+srv://jad2001abi1:HELLOworld123@firstproject.tv6nvbr.mongodb.net/?retryWrites=true&w=majority")
.then(()=>{
    console.log("mongo connected")
})
.catch(()=>{
    console.log("error")
})

module.exports=Collection
