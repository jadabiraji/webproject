const express = require('express');
const app = express();
const path = require('path')


app.use(express.json())
app.use(express.urlencoded({extended:false}))

app.set('views', './views');
app.set('view engine', 'ejs');
const csspages= path.join(__dirname, "./css")
app.use(express.static(csspages))

//app.use(express.static(images))

app.use('/images',express.static('./images'));
app.use('/css',express.static('./css'));
app.use('/js',express.static('js'));

app.get("/",(req,res)=>{
res.render("index")})

app.listen(3033,()=>{
    console.log("connected")
})

